import React from 'react'
import './AtelierExperience.css'

type Language = 'ar' | 'en'

interface Props {
  language: Language
}

interface World {
  number: string
  name: string
  description: string
  status: string
  active: boolean
}

const COPY = {
  en: {
    eyebrow: 'FX2 / CREATIVE INTELLIGENCE',
    headline: 'One intelligence. Three creative worlds.',
    subline: 'From Text to Thought. From Thought to Creation.',
    activeLabel: 'ACTIVE EXPERIENCE',
    nextLabel: 'IN DEVELOPMENT',
    worlds: [
      {
        number: '01',
        name: 'The Atelier',
        description: 'Brief → Insight → Concept. Find the thought worth creating.',
        status: 'WORKSPACE ACTIVE',
        active: true,
      },
      {
        number: '02',
        name: 'Neural Lab',
        description: 'Experiments, evidence, provocation and alternative thinking.',
        status: 'NEXT EXPERIENCE',
        active: false,
      },
      {
        number: '03',
        name: "Director’s Stage",
        description: 'Narrative architecture, cinematic scripts and production language.',
        status: 'NEXT EXPERIENCE',
        active: false,
      },
    ],
  },
  ar: {
    eyebrow: 'FX2 / الذكاء الإبداعي',
    headline: 'ذكاء إبداعي واحد. ثلاثة عوالم مختلفة.',
    subline: 'من النص إلى الفكرة. ومن الفكرة إلى الإبداع.',
    activeLabel: 'التجربة النشطة',
    nextLabel: 'قيد التطوير',
    worlds: [
      {
        number: '01',
        name: 'The Atelier',
        description: 'من الملخص إلى البصيرة ثم المفهوم — الفكرة التي تستحق أن تُخلق.',
        status: 'مساحة العمل النشطة',
        active: true,
      },
      {
        number: '02',
        name: 'Neural Lab',
        description: 'تجارب، أدلة، استفزاز فكري، ومسارات تفكير بديلة.',
        status: 'التجربة التالية',
        active: false,
      },
      {
        number: '03',
        name: "Director’s Stage",
        description: 'بناء السرد، كتابة السيناريو السينمائي، ولغة الإنتاج.',
        status: 'التجربة التالية',
        active: false,
      },
    ],
  },
} satisfies Record<Language, {
  eyebrow: string
  headline: string
  subline: string
  activeLabel: string
  nextLabel: string
  worlds: World[]
}>

export default function AtelierExperience({ language }: Props) {
  const copy = COPY[language]

  return (
    <section className="fx2-worlds" aria-label={language === 'ar' ? 'عوالم FX2' : 'FX2 creative worlds'}>
      <div className="fx2-worlds__intro">
        <div className="fx2-worlds__eyebrow">
          <span className="fx2-worlds__signal" aria-hidden="true" />
          {copy.eyebrow}
        </div>
        <div className="fx2-worlds__heading">
          <h2>{copy.headline}</h2>
          <p>{copy.subline}</p>
        </div>
      </div>

      <div className="fx2-worlds__grid">
        {copy.worlds.map((world) => (
          <article
            key={world.number}
            className={`fx2-world${world.active ? ' is-active' : ' is-future'}`}
            aria-current={world.active ? 'page' : undefined}
            aria-label={`${world.name} — ${world.active ? copy.activeLabel : copy.nextLabel}`}
          >
            <div className="fx2-world__topline">
              <span className="fx2-world__number">{world.number}</span>
              <span className="fx2-world__status">
                <span className="fx2-world__status-dot" aria-hidden="true" />
                {world.active ? copy.activeLabel : copy.nextLabel}
              </span>
            </div>
            <h3>{world.name}</h3>
            <p>{world.description}</p>
            <div className="fx2-world__foot">
              <span>{world.status}</span>
              <span className="fx2-world__arrow" aria-hidden="true">↗</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}
