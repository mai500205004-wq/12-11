import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const defaultAppPath = path.join(
  process.cwd(),
  'unzipped_project', 'archive_1', 'FX2-main', 'Fxfx-main', 'app', 'src', 'App.tsx'
)
const appPath = path.resolve(process.argv[2] || defaultAppPath)
const componentSource = path.join(here, 'atelier', 'AtelierExperience.tsx')
const styleSource = path.join(here, 'atelier', 'AtelierExperience.css')

function requireExactlyOnce(source, needle, label) {
  const count = source.split(needle).length - 1
  if (count !== 1) {
    throw new Error(`${label}: expected exactly one match, found ${count}. No project files were changed.`)
  }
}

for (const file of [appPath, componentSource, styleSource]) {
  if (!fs.existsSync(file)) throw new Error(`Required file not found: ${file}`)
}

const original = fs.readFileSync(appPath, 'utf8')
const importAnchor = "import { backendFetch } from './backend-fetch'"
const logoAnchor = '<div className="nav-logo">TEXT<span>FX</span></div>'
const navAnchor = '      </nav>\n\n      {/* ── Hero'
const footerAnchor = '<div className="footer-logo">TEXTFX</div>'

requireExactlyOnce(original, importAnchor, 'Import anchor')
requireExactlyOnce(original, logoAnchor, 'Navigation logo anchor')
requireExactlyOnce(original, navAnchor, 'Navigation insertion anchor')
requireExactlyOnce(original, footerAnchor, 'Footer logo anchor')

let updated = original
updated = updated.replace(importAnchor, `${importAnchor}\nimport AtelierExperience from './components/AtelierExperience'`)
updated = updated.replace(logoAnchor, '<div className="nav-logo" aria-label="FX2 Creative Intelligence">FX<span>2</span></div>')
updated = updated.replace(
  navAnchor,
  `      </nav>\n\n      <AtelierExperience language={lang} />\n\n      {/* ── Hero`
)
updated = updated.replace(footerAnchor, '<div className="footer-logo">FX2</div>')

const componentDir = path.join(path.dirname(appPath), 'components')
const componentDest = path.join(componentDir, 'AtelierExperience.tsx')
const styleDest = path.join(componentDir, 'AtelierExperience.css')
for (const file of [componentDest, styleDest]) {
  if (fs.existsSync(file)) throw new Error(`Refusing to overwrite existing file: ${file}. No project files were changed.`)
}

fs.mkdirSync(componentDir, { recursive: true })
fs.copyFileSync(componentSource, componentDest)
fs.copyFileSync(styleSource, styleDest)
const backupPath = `${appPath}.before-fx2-atelier`
fs.copyFileSync(appPath, backupPath)
fs.writeFileSync(appPath, updated, 'utf8')

console.log('FX2 Atelier integration applied successfully.')
console.log(`Updated: ${appPath}`)
console.log(`Added:   ${componentDest}`)
console.log(`Added:   ${styleDest}`)
console.log(`Backup:  ${backupPath}`)
console.log('No dependencies or backend routes were changed.')
