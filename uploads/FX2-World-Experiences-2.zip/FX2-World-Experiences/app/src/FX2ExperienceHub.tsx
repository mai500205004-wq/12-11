import { useState } from 'react'
import './fx2-experience-hub.css'

export type FX2World = 'atelier' | 'neural-lab' | 'director-stage'

type FX2ExperienceHubProps = {
  lang: 'ar' | 'en'
  hasInsight: boolean
  hasConcept: boolean
  hasScript: boolean
  onNavigate: (world: FX2World) => void
}

type WorldContent = {
  id: FX2World
  index: string
  eyebrow: string
  title: string
  description: string
  state: string
  action: string
}

export default function FX2ExperienceHub({
  lang,
  hasInsight,
  hasConcept,
  hasScript,
  onNavigate,
}: FX2ExperienceHubProps) {
  const isArabic = lang === 'ar'
  const [activeWorld, setActiveWorld] = useState<FX2World>(() => {
    if (typeof window === 'undefined') return 'atelier'
    try {
      const saved = window.localStorage.getItem('fx2-active-world')
      return saved === 'atelier' || saved === 'neural-lab' || saved === 'director-stage'
        ? saved
        : 'atelier'
    } catch {
      return 'atelier'
    }
  })

  const worlds: WorldContent[] = isArabic
    ? [
        {
          id: 'atelier', index: '01', eyebrow: 'THE ATELIER', title: 'المشغل الإبداعي',
          description: 'ابدأ من الملخص. اكتشف التوتر الخفي. حوّله إلى اتجاه إبداعي واضح.',
          state: 'من الملخص إلى الفكرة', action: 'ادخل المشغل',
        },
        {
          id: 'neural-lab', index: '02', eyebrow: 'NEURAL LAB', title: 'مختبر التفكير',
          description: 'اكسر الافتراضات، اربط إشارات بعيدة، واختبر زوايا لم تظهر من قبل.',
          state: hasInsight ? 'البصيرة جاهزة للاستكشاف' : 'بانتظار أول بصيرة',
          action: hasInsight ? 'استكشف البصيرة' : 'ابدأ التجربة',
        },
        {
          id: 'director-stage', index: '03', eyebrow: "DIRECTOR'S STAGE", title: 'خشبة المخرج',
          description: 'حوّل المفهوم إلى مشهد، وإيقاع، ولغة إنتاج سينمائية.',
          state: hasScript ? 'السيناريو جاهز' : hasConcept ? 'المفهوم جاهز للإنتاج' : 'ابدأ من الفكرة',
          action: hasScript ? 'افتح السيناريو' : 'ادخل غرفة الإنتاج',
        },
      ]
    : [
        {
          id: 'atelier', index: '01', eyebrow: 'THE ATELIER', title: 'The Atelier',
          description: 'Shape the brief. Find the hidden tension. Reveal a clear creative direction.',
          state: 'Brief → Insight → Concept', action: 'Enter the atelier',
        },
        {
          id: 'neural-lab', index: '02', eyebrow: 'NEURAL LAB', title: 'Neural Lab',
          description: 'Break assumptions, connect distant signals, and test unexpected angles.',
          state: hasInsight ? 'Insight ready to explore' : 'Awaiting the first insight',
          action: hasInsight ? 'Explore the insight' : 'Start the experiment',
        },
        {
          id: 'director-stage', index: '03', eyebrow: "DIRECTOR'S STAGE", title: "Director's Stage",
          description: 'Turn the concept into scenes, rhythm, and a cinematic production language.',
          state: hasScript ? 'Script ready' : hasConcept ? 'Concept ready for production' : 'Start with an idea',
          action: hasScript ? 'Open the script' : 'Enter production',
        },
      ]

  const heading = isArabic ? 'ثلاثة عوالم. عقل إبداعي واحد.' : 'Three worlds. One creative intelligence.'
  const intro = isArabic
    ? 'كل عالم له طريقته في التفكير وصناعة النتيجة. اختر المساحة التي تحتاجها الآن.'
    : 'Each world has its own way of thinking and making. Choose the space you need now.'
  const selectedLabel = isArabic ? 'العالم النشط' : 'ACTIVE EXPERIENCE'
  const signature = isArabic ? 'فكّر أبعد. اصنع ما لم يأتِ بعد.' : 'Think Beyond. Create What’s Next.'

  function selectWorld(world: FX2World) {
    setActiveWorld(world)
    try {
      window.localStorage.setItem('fx2-active-world', world)
    } catch {
      // The experience selector remains functional when storage is unavailable.
    }
    onNavigate(world)
  }

  return (
    <section className="fx2-hub" aria-labelledby="fx2-hub-title" dir={isArabic ? 'rtl' : 'ltr'}>
      <div className="fx2-hub-heading">
        <div>
          <div className="fx2-hub-brand"><span>FX2</span><i />CREATIVE INTELLIGENCE</div>
          <h2 id="fx2-hub-title">{heading}</h2>
          <p>{intro}</p>
        </div>
        <div className="fx2-hub-signature" aria-hidden="true">{signature}</div>
      </div>

      <div className="fx2-world-grid">
        {worlds.map(world => (
          <button
            key={world.id}
            type="button"
            className={`fx2-world-card fx2-world-card--${world.id}${activeWorld === world.id ? ' is-active' : ''}`}
            aria-pressed={activeWorld === world.id}
            onClick={() => selectWorld(world.id)}
          >
            <div className={`fx2-world-art fx2-world-art--${world.id}`} aria-hidden="true">
              {world.id === 'atelier' && (
                <div className="fx2-art-atelier">
                  <span className="atelier-sheet atelier-sheet--back" />
                  <span className="atelier-sheet atelier-sheet--mid" />
                  <span className="atelier-sheet atelier-sheet--front"><i /><i /><i /></span>
                  <span className="atelier-orbit" />
                </div>
              )}
              {world.id === 'neural-lab' && (
                <div className="fx2-art-neural">
                  <span className="neural-ring neural-ring--one" />
                  <span className="neural-ring neural-ring--two" />
                  <span className="neural-node neural-node--a" />
                  <span className="neural-node neural-node--b" />
                  <span className="neural-node neural-node--c" />
                  <span className="neural-node neural-node--d" />
                  <span className="neural-core" />
                </div>
              )}
              {world.id === 'director-stage' && (
                <div className="fx2-art-stage">
                  <span className="stage-beam" />
                  <span className="stage-frame stage-frame--back" />
                  <span className="stage-frame stage-frame--front" />
                  <span className="stage-floor" />
                  <span className="stage-marker" />
                </div>
              )}
            </div>

            <div className="fx2-world-card-meta">
              <span>{world.index} / {world.eyebrow}</span>
              <span className="fx2-world-dot" aria-hidden="true" />
            </div>
            <h3>{world.title}</h3>
            <p className="fx2-world-description">{world.description}</p>
            <div className="fx2-world-card-footer">
              <span className="fx2-world-state">{world.state}</span>
              <span className="fx2-world-action">{world.action}<b aria-hidden="true">↗</b></span>
            </div>
          </button>
        ))}
      </div>

      <div className="fx2-hub-footer">
        <span>{selectedLabel}</span>
        <strong>{worlds.find(world => world.id === activeWorld)?.eyebrow}</strong>
        <span className="fx2-hub-footer-line" />
        <span>{isArabic ? 'تجربة واحدة متصلة بمحركات FX2 الحالية' : 'One connected experience, powered by the existing FX2 engines'}</span>
      </div>
    </section>
  )
}
