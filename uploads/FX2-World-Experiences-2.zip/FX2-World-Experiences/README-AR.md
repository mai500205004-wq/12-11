# FX2 — Experience Worlds Integration

هذه الحزمة تضيف طبقة اختيار العوالم الثلاثة داخل تطبيق React الحالي، من دون استبدال محركات التوليد أو تغيير عقود الـBackend.

## الملفات

- `app/src/FX2ExperienceHub.tsx` — مكوّن React لاختيار العالم، مع عربي/إنجليزي وحفظ الاختيار محليًا.
- `app/src/fx2-experience-hub.css` — الهوية البصرية الخاصة بكل عالم، responsive وRTL.
- `App.integration.patch` — رقعة الدمج المحدودة لملف `App.tsx`.

## أماكن الدمج

المسار المستهدف داخل المستودع:

`unzipped_project/archive_1/FX2-main/Fxfx-main/app/src/`

1. انسخ الملفين داخل `app/src/`.
2. طبّق `App.integration.patch` من جذر المستودع، أو نفّذ الإضافات الثلاث الموضحة داخله يدويًا.
3. لا تحتاج الحزمة إلى dependencies إضافية أو أي تعديل في backend.

## سلوك الاختيار

- **The Atelier:** يوجّه المستخدم إلى brief الحالي.
- **Neural Lab:** يفتح نتيجة insight الموجودة، أو يعيد المستخدم إلى brief لتشغيل المحركات الحالية.
- **Director’s Stage:** يفتح script، ثم concept، أو brief حسب المرحلة المتاحة.

هذا مقصود: الحزمة تخلق مدخلًا موحدًا للعوالم، لكنها لا تدّعي وجود ثلاثة محركات مستقلة غير موجودة في الكود. محركات Insight وConcept وScript الحالية تظل مصدر التنفيذ.

## التحقق

تم التحقق من صياغة TypeScript/JSX للمكوّن باستخدام TypeScript transpile parser. لم يتم تشغيل `npm run typecheck` أو `npm run build` على المستودع الكامل، ولم يتم رفع التغييرات إلى GitHub لأن إنشاء فرع أعاد HTTP 403.
