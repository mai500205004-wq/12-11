import { randomUUID } from 'node:crypto'
import { mapConcept } from './concept-mapper'
import type { CreativeCandidate } from '../core/creative-ir'
import type { LateralThinkingContext } from './lateral-thinking-agent'

export interface MetabolismResult {
  candidates: CreativeCandidate[]
  offspring: CreativeCandidate[]
  events: Array<{ type: 'mutation' | 'crossover' | 'skipped'; message: string; parentIds: string[] }>
}

function conceptText(candidate: CreativeCandidate): string {
  const c = candidate.concept
  return [c.title, c.tagline, c.coreIdea, c.visualNotes, c.creativeDevice, c.emotionalArc, c.targetParadox].join(' ')
}

function tokenSet(value: string): Set<string> {
  return new Set((value.toLocaleLowerCase().match(/[\p{L}\p{N}]{3,}/gu) ?? []))
}

function jaccardSimilarity(a: string, b: string): number {
  const left = tokenSet(a)
  const right = tokenSet(b)
  if (!left.size || !right.size) return 0
  let intersection = 0
  for (const token of left) if (right.has(token)) intersection++
  return intersection / (left.size + right.size - intersection)
}

/**
 * Keep the highest-scoring seed as the primary crossover parent, but choose
 * its partner by lexical complementarity. Score is only a tie-breaker:
 * Creative Court still evaluates every seed and offspring.
 */
function selectCrossoverPartner(primary: CreativeCandidate, alternatives: CreativeCandidate[]): CreativeCandidate {
  return [...alternatives].sort((a, b) => {
    const similarityDelta = jaccardSimilarity(conceptText(primary), conceptText(a))
      - jaccardSimilarity(conceptText(primary), conceptText(b))
    return similarityDelta || b.score - a.score
  })[0]
}

function novelty(candidate: string, parents: string[]): number {
  const own = tokenSet(candidate)
  const parentTokens = new Set(parents.flatMap(parent => [...tokenSet(parent)]))
  if (!own.size) return 0
  let newCount = 0
  for (const token of own) if (!parentTokens.has(token)) newCount++
  return newCount / own.size
}

/**
 * Creates a bounded next generation from existing seed concepts: one mutation and one crossover.
 * The LLM remains the concept generator; this module supplies explicit lineage and constraints.
 * Failures are isolated so seed concepts remain usable.
 */
export async function metabolizeIdeas(
  seeds: CreativeCandidate[],
  insight: { mainInsight?: string },
  context: LateralThinkingContext,
  maxOffspring = 2,
): Promise<MetabolismResult> {
  if (!seeds.length) throw new Error('Idea Metabolism requires at least one seed candidate.')
  const limit = Math.max(0, Math.min(2, Math.floor(maxOffspring)))
  const offspring: CreativeCandidate[] = []
  const events: MetabolismResult['events'] = []
  if (!limit) return { candidates: [...seeds], offspring, events }

  const ranked = [...seeds].sort((a, b) => b.score - a.score)
  const plans: Array<{ kind: 'mutation' | 'crossover'; parents: CreativeCandidate[]; instruction: string }> = []
  plans.push({
    kind: 'mutation', parents: [ranked[0]],
    instruction: 'MUTATION: Preserve the parent concept\'s strategic core, but change its creative mechanism, emotional turn, or visual execution in a genuinely meaningful way. Do not merely rephrase it. State a clearly executable new variant.',
  })
  if (limit > 1 && ranked.length > 1) {
    const crossoverPartner = selectCrossoverPartner(ranked[0], ranked.slice(1))
    plans.push({
      kind: 'crossover', parents: [ranked[0], crossoverPartner],
      instruction: 'CROSSOVER: Combine the strongest complementary mechanisms of both parent concepts into one coherent third concept. Prefer genuinely different metaphor families and creative mechanisms; do not concatenate them. Resolve contradictions and preserve a single clear strategic idea.',
    })
  }

  const results = await Promise.all(plans.slice(0, limit).map(async plan => {
    const parentsText = plan.parents.map((parent, index) => `PARENT ${index + 1} (${parent.lens}):\n${conceptText(parent)}`).join('\n\n')
    const mainInsight = `${insight.mainInsight || ''}\n\n${plan.instruction}\n\n${parentsText}`
    const childContext: LateralThinkingContext = {
      ...context,
      target: `${context.target}\n\nEvolution operation: ${plan.kind}. Parent IDs: ${plan.parents.map(parent => parent.id).join(', ')}. ${plan.instruction}`,
      problem: `${context.problem}\n\nEvolution parents:\n${parentsText}\n\nGenerate a new child concept, not a summary of the parents.`,
    }
    try {
      const concept = await mapConcept({ mainInsight }, childContext)
      const parentIds = plan.parents.map(parent => parent.id)
      const noveltyScore = novelty(conceptText({ ...plan.parents[0], concept }), plan.parents.map(conceptText))
      const parentScore = plan.parents.reduce((sum, parent) => sum + parent.score, 0) / plan.parents.length
      const score = Math.max(0, Math.min(100, Math.round(parentScore * 0.7 + noveltyScore * 30)))
      const candidate: CreativeCandidate = {
        id: randomUUID(),
        lens: plan.kind === 'mutation' ? 'Metabolic Mutation' : 'Concept Crossover',
        lensId: plan.kind,
        version: 1,
        runId: context.runId || seeds[0].runId,
        promptVersion: context.promptVersion || seeds[0].promptVersion,
        concept,
        score,
        rationale: [
          `Generated by bounded ${plan.kind} from ${parentIds.length} parent concept(s).`,
          `Parent IDs: ${parentIds.join(', ')}.`,
          `Novel-token ratio heuristic: ${Math.round(noveltyScore * 100)}%; this is not a measure of artistic quality.`,
        ],
        origin: plan.kind,
        parentIds,
        generation: Math.max(...plan.parents.map(parent => parent.generation ?? 0)) + 1,
      }
      return { ok: true as const, candidate, kind: plan.kind, parentIds }
    } catch (error) {
      return { ok: false as const, kind: plan.kind, parentIds: plan.parents.map(parent => parent.id), message: error instanceof Error ? error.message : String(error) }
    }
  }))

  for (const result of results) {
    if (result.ok) {
      offspring.push(result.candidate)
      events.push({ type: result.kind, message: `Created ${result.candidate.lens} candidate ${result.candidate.id}.`, parentIds: result.parentIds })
    } else {
      events.push({ type: 'skipped', message: `${result.kind} failed; seed concepts retained. ${result.message}`, parentIds: result.parentIds })
    }
  }
  return { candidates: [...seeds, ...offspring], offspring, events }
}
